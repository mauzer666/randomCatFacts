Создаем Github - ферму. Прокачка акков для Gitcoin Passport.

main.js - файл с кодом на NodeJS

Main-Python.txt - файл с кодом на Python

Без подписки на ТГ и Youtube у Вас может ничего не получиться, поэтому сначала подписываемся и ставим лайки, а потом читаем и действуем в соответствии с гайдом. 

Это не шутка...

Подробная статья:  https://teletype.in/@bitfuture/WRKYjXHVO78


ТГ канал:   https://t.me/NewBitFuture


Youtube с видео-гайдом:  https://youtu.be/7_vshCjhLi0
